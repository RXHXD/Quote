import React from "react"
export const DisplayCounter = (props) => {  
  return(
    <div>
        <h1>Counter : {props.count}</h1>
    </div>
  )

}